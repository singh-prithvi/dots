-- lua/config/utils.lua
-- Shared helpers used across the config.
-- Keep this module free of side-effects — it is required at startup.
local M = {}

--- Walk up the directory tree from `dir` looking for a file/directory named
--- `marker`. Stops as soon as a `.git` boundary is crossed (i.e. never
--- escapes a project root).  Returns the first directory that contains
--- `marker`, or nil.
---
---@param dir    string  absolute starting directory
---@param marker string  filename or dirname to search for (e.g. "Makefile")
---@return string|nil
function M.find_project_root(dir, marker)
    local current = dir
    while true do
        if vim.fn.filereadable(current .. "/" .. marker) == 1
            or vim.fn.isdirectory(current .. "/" .. marker) == 1
        then
            return current
        end
        -- Never cross a git boundary
        if vim.fn.isdirectory(current .. "/.git") == 1 then
            return nil
        end
        local parent = vim.fn.fnamemodify(current, ":h")
        if parent == current then
            break -- reached filesystem root
        end
        current = parent
    end
    return nil
end

return M
